# -*- coding: utf-8 -*-

from pyspark.sql import SparkSession, SQLContext

class DadosIO:
    _spark = None
    _sqlContext = None

    _diretorio_windows = '../Smtx/Dados/'
    _diretorio = ''

    def __init__(self, job):
        if DadosIO._spark is None:
            DadosIO._spark = SparkSession.builder.appName(job).getOrCreate()
            DadosIO._sqlContext = SQLContext(self._spark)

    # Inicializando as funcionalidades do Spark
    def spark_session(self):
        return DadosIO._spark

    # Log arquivo
    def nasa_result(self, nomearquivo =""):
        return DadosIO._spark.read.option("encoding", "utf-8").csv(DadosIO._diretorio_windows + nomearquivo, sep=' ')

    # Gravacao arquivo
    def gravar(self, df, nome):
        df.repartition(1).write.csv(DadosIO._diretorio + nome, header=True, mode='overwrite', sep='|')



class ProdDadosIO:
    _spark = None

    def __init__(self, job):
        if ProdDadosIO._spark is None:
            ProdDadosIO._spark = SparkSession.builder.appName(job) \
                .config("hive.exec.dynamic.partition", "true") \
                .config("hive.exec.dynamic.partition.mode", "nonstrict") \
                .enableHiveSupport() \
                .getOrCreate()

    def spark_session(self):
        return ProdDadosIO._spark

    # Nasa logs
    def nasa_result(self):
        return ProdDadosIO._spark.read.table('raw_sm.nasa_logs')

    # Gravacao HIVE
    def gravar(self, df, nome):
        df.write.option("compression", "zlib").option("encoding", "UTF-8").mode(
            "overwrite").format("orc").option(
            "header", "false").insertInto(nome, overwrite=True)
