# -*- coding: utf-8 -*-

from pyspark.sql.functions import regexp_extract
from pyspark.sql import functions as f


'''
    Dataframes.
'''

def sql(df):
    print("Numero de hosts unicos:")
    print(df.select("_c0").distinct().count())
    print("Quantidade de erros 404")
    print(df.filter(df["_c6"] == "404").count())
    print("5 URLS que mais causaram erro 404")
    df.filter(df["_c6"] == "404").select(df["_c0"]).groupBy(df["_c0"]).count().sort(f.col("count").desc()).show(5)
    print("Quantidades de codigos 404 por dia")
    df.filter(df["_c6"] == "404").select(df["_c3"]).groupBy(df["_c3"]).count().sort(f.col("count").desc()).show()
    print("Total de bytes")
    df.select(df["_c7"]).agg(f.sum('_c7').alias('total_bytes')).show()