# -*- coding: utf-8 -*-

import sys, os

from Dados import dados_io_smtx
from Gerenciadores import gerenciadores_smtx

# Base - DataLake
_producao = False
_dados_io = None

if not _producao:
    _dados_io = dados_io_smtx.DadosIO('SMTX')
    _main_gerenciador = gerenciadores_smtx.Gerenciador(_dados_io)
    _main_gerenciador.principal()


else:
    _dados_io = dados_io_smtx.ProdDadosIO('STMTX')
    _main_gerenciador = gerenciadores_smtx.Gerenciador(_dados_io)





