Prezado candidato. 
Gostar�amos de fazer um teste que ser� usado para sabermos a sua profici�ncia nas habilidades para a vaga. O teste consiste em algumas perguntas e exerc�cios pr�ticos sobre Spark e as respostas e c�digos implementados devem ser armazenados no GitHub. O link do seu reposit�rio deve ser compartilhado conosco ao final do teste. 
Quando usar alguma refer�ncia ou biblioteca externa, informe no arquivo README do seu projeto. Se tiver alguma d�vida, use o bom senso e se precisar deixe isso registrado na documenta��o do projeto. 
Qual o objetivo do comando cache em Spark? 
O objetivo � melhorar o desempenho na execu��o dos dados.

O mesmo c�digo implementado em Spark � normalmente mais r�pido que a implementa��o equivalente em MapReduce. Por qu�?     
Porque o modelo MapReduce representa uma sobrecarga significativa, muitos processamentos realizados com os mesmos dados, sendo lido uma �nica vez, mas interagindo v�rias vezes. Diferentemente o Spark executa o processamento em mem�ria, usando RDDs
Qual � a fun��o do SparkContext? 
� um objeto que tem a fun��o de acessar o cluster.

Explique com suas palavras o que � Resilient Distributed Datasets (RDD). 
S�o blocos de dados resilientes distribu�dos, que serve como conjuntos para tolerar falhas de elementos executados em paralelo.

GroupByKey � menos eficiente que reduceByKey em grandes dataset. Por qu�? 
No GroupByKey � menos eficiente porque � aplicado diretamente em toda a rede.
J� no reduceByKey a opera��o de redu��o � aplicada na primeira parti��o e 
depois ela � usada na rede, reduzindo o tr�fego.

Explique o que o c�digo Scala abaixo faz. 
val textFile = sc.textFile("hdfs://...") 
val counts = textFile.flatMap(line => line.split(" ")) 
.map(word => (word, 1)) 
.reduceByKey(_ + _)
counts.saveAsTextFile("hdfs://...") 

1. L� o arquivo no diret�rio do hdfs;
2. O split separa as palavras ao encontrar um espa�o vazio, o flatMap transforma o conjunto de linhas em conjuntos de palavras;
3. No map aplica transforma��o em cada elemento, resultando em v�rios outros elementos;
4. o reduceByKey serve para achatar os elemtentos para uma dimens�o apenas;
5. Por fim, salva o arquivo de texto counts no diret�rio do hdfs.


HTTP requests to the NASA Kennedy Space Center WWW server 
Fonte oficial do dateset: http://ita.ee.lbl.gov/html/contrib/NASA-HTTP.html 
Dados: 
? Jul 01 to Jul 31, ASCII format, 20.7 MB gzip compressed, 205.2 MB. 
? Aug 04 to Aug 31, ASCII format, 21.8 MB gzip compressed, 167.8 MB. 
Sobre o dataset: Esses dois conjuntos de dados possuem todas as requisi��es HTTP para o servidor da NASA Kennedy 
Space Center WWW na Fl�rida para um per�odo espec�fico. 
Os logs est�o em arquivos ASCII com uma linha por requisi��o com as seguintes colunas: 
? Host fazendo a requisi��o. Um hostname quando poss�vel, caso contr�rio o endere�o de internet se o nome 
n�o puder ser identificado. 
? Timestamp no formato "DIA/M�S/ANO:HH:MM:SS TIMEZONE" 
? Requisi��o (entre aspas) 
? C�digo do retorno HTTP 
? Total de bytes retornados 
Quest�es 
Responda as seguintes quest�es devem ser desenvolvidas em Spark utilizando a sua linguagem de prefer�ncia. 
1. N�mero de hosts �nicos. 
2. O total de erros 404. 
3. Os 5 URLs que mais causaram erro 404. 
4. Quantidade de erros 404 por dia. 
5. O total de bytes retornados.

Refer�ncias: https://spark.apache.org/docs/latest/index.html
