# -*- coding: utf-8 -*-

import Regras.sql_smtx as igt_sql
import pyspark.sql.functions as f


class Gerenciador:
    # Conexao (session) do Spark e acesso a dados
    _dados_io = None
    _spark_session = None

    # Dataframes originais
    df_nasa_result = None
    df_nasa_view = None

    def __init__(self, _dados_io):
        self._dados_io = _dados_io
        self._spark_session = _dados_io.spark_session()

        self.dfFinal = _dados_io.nasa_result()


    def principal(self):
        igt_sql.sql(self.dfFinal)
